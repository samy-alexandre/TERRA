# 🎮 NEON HORDE — Guide complet (jeu + publication + argent)

Tu as un jeu **complet et fonctionnel**. Voici TOUT ce qu'il faut savoir, expliqué simplement.

---

## 1. CE QUE TU AS

Un roguelite survivor complet :
- ✅ Gameplay addictif (bouge, l'attaque est auto, survis)
- ✅ 5 personnages jouables (gameplay différent)
- ✅ 5 skins cosmétiques
- ✅ 10 améliorations en partie + 5 améliorations permanentes
- ✅ Boss tous les 5 vagues
- ✅ Système de progression (or + gems)
- ✅ Sauvegarde automatique
- ✅ Monétisation intégrée (skins, persos premium, packs de gems, revive)
- ✅ Tactile (mobile) + clavier (PC)
- ✅ Polish : particules, screen shake, sons, dégâts critiques

**Teste-le maintenant** : ouvre `index.html` dans un navigateur (double-clic).

---

## 2. COMMENT GAGNER DE L'ARGENT AVEC

Le jeu a **4 sources de revenus** déjà codées :

### A) Achats intégrés (IAP) — packs de gems
Dans la boutique : packs à 1,99€ / 4,99€ / 14,99€.
**Actuellement en mode DÉMO** (donne les gems gratuitement pour tester).
En production → branché sur Google Play Billing (voir section 4).

### B) Cosmétiques (skins)
Les joueurs achètent des skins avec gems (monnaie premium).
C'est LE modèle qui marche (Fortnite, etc.) — vendre du cosmétique, pas de la puissance.

### C) Personnages premium
2 persos achetables en gems (Arcane, Spectre).

### D) Revive payant
À la mort : "Revivre pour 15 gems". Conversion classique mobile.

### + Pub récompensée (à ajouter, section 5)
"Regarde une pub = +50 or" ou "Revive gratuit avec une pub".

---

## 3. PUBLIER SUR GOOGLE PLAY — étape par étape

Ton jeu est en HTML5. Pour le mettre sur le Play Store, il faut le "wrapper" dans une app Android. **C'est plus simple que ça en a l'air.**

### Option recommandée : Capacitor (gratuit, moderne)

**Pré-requis (à installer une fois) :**
- Node.js (déjà installé si tu testes ce projet)
- Android Studio : https://developer.android.com/studio

**Les commandes (copie-colle, une par une) :**

```bash
# 1. Dans le dossier du jeu
cd neonhorde

# 2. Initialiser le projet
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android

# 3. Créer la structure web (mettre index.html dans un dossier www)
mkdir www
cp index.html www/

# 4. Initialiser Capacitor
npx cap init "NEON HORDE" "com.tonnom.neonhorde" --web-dir=www

# 5. Ajouter Android
npx cap add android

# 6. Synchroniser
npx cap sync

# 7. Ouvrir dans Android Studio
npx cap open android
```

Dans Android Studio : **Build > Generate Signed Bundle/APK** → suis l'assistant pour créer ton fichier `.aab` (le format demandé par Google Play).

### Compte développeur Google Play
- Inscription : https://play.google.com/console
- **Coût : 25 $ une seule fois** (à vie)
- Délai de validation : 1-7 jours pour le 1er jeu

### Checklist avant soumission
- [ ] Icône de l'app (512×512 px) — je peux t'en générer une
- [ ] Captures d'écran (min 2, format téléphone)
- [ ] Description courte + longue
- [ ] Politique de confidentialité (obligatoire — générateur gratuit : https://app-privacy-policy-generator.firebaseapp.com)
- [ ] Classification du contenu (questionnaire dans la console)
- [ ] Fichier `.aab` signé

---

## 4. BRANCHER LES VRAIS PAIEMENTS (Google Play Billing)

Le code a une fonction `mockBuyGems()` en mode démo. Pour la production :

1. Dans Google Play Console → **Produits intégrés à l'application** → créer 3 produits :
   - `gems_50` (1,99€), `gems_150` (4,99€), `gems_500` (14,99€)

2. Ajouter le plugin Capacitor :
```bash
npm install @capacitor-community/in-app-purchases
npx cap sync
```

3. Remplacer la fonction `mockBuyGems` (un dev peut le faire en ~1h, ou je peux te guider).

> ⚠️ Google prend **15% de commission** (sous 1M$/an, sinon 30%).

---

## 5. AJOUTER LES PUBS (revenus passifs)

Pub récompensée = grosse source de revenus pour les jeux gratuits.

```bash
npm install @capacitor-community/admob
npx cap sync
```

Crée un compte AdMob (Google) : https://admob.google.com
Puis on ajoute un bouton "Pub = +100 or" et "Revive gratuit (pub)".

**Revenu typique** : 5-15€ pour 1000 pubs regardées (eCPM). Avec 1000 joueurs/jour actifs → ~50-150€/jour potentiel.

---

## 6. MARKETING — comment avoir des joueurs (gratuit)

Stratégie réaliste pour un solo sans budget :

1. **TikTok / YouTube Shorts / Reels** : filme des clips de gameplay satisfaisants (15-30s). C'est CE qui fait découvrir les jeux indé aujourd'hui. 1 vidéo virale = 10 000+ téléchargements.
2. **Reddit** : r/AndroidGaming, r/incremental_games, r/WebGames — poste ton jeu (sans spam, raconte ton histoire de dev solo).
3. **itch.io** : publie la version web gratuitement, ça génère du feedback + visibilité.
4. **ASO (App Store Optimization)** : mots-clés dans le titre/description ("survivor", "roguelite", "neon", "horde").
5. **Discord / communautés indé** : montre ton dev en public ("je fais un jeu", les gens adorent suivre).

**Le secret** : un clip TikTok satisfaisant > tout budget pub. Vampire Survivors a explosé via le bouche-à-oreille et les streamers.

---

## 7. CHIFFRES RÉALISTES (sois pas naïf)

| Scénario | Téléchargements | Revenu/mois estimé |
|---|---|---|
| Lancement discret | 100-1 000 | 5-50 € |
| Un clip qui marche | 10 000-50 000 | 200-2 000 € |
| Vrai hit (rare) | 500 000+ | 10 000 €+ |

**95% des jeux indé gagnent peu.** Les 5% qui percent ont : un hook viral + de la chance + de l'itération constante (mises à jour, écoute des joueurs).

Ce jeu te donne une **base solide et vendable**. Le succès dépend ensuite du marketing et de l'itération — pas juste du code.

---

## 8. PROCHAINES ÉTAPES (par où commencer)

**Aujourd'hui :**
1. Teste le jeu (ouvre index.html)
2. Dis-moi ce que tu veux ajuster (difficulté, contenu, équilibrage)

**Cette semaine :**
3. Je peux te générer : icône, captures, description Play Store
4. Je peux ajouter : pubs récompensées, plus de contenu, succès/achievements

**Quand prêt :**
5. On wrappe avec Capacitor → fichier .aab
6. Compte Google Play (25$) → soumission

Dis-moi par quoi tu veux qu'on continue. Je suis ton équipe complète.
